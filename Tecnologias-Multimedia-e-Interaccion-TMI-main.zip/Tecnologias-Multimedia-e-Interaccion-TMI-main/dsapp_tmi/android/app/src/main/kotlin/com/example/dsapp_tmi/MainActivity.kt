package com.example.dsapp_tmi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
